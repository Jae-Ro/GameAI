'''
 * Copyright (c) 2014, 2015 Entertainment Intelligence Lab, Georgia Institute of Technology.
 * Originally developed by Mark Riedl.
 * Last edited by Mark Riedl 05/2015
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
'''

import sys
import pygame
import math
import numpy
import random
import time
import copy
import heapq
from pygame.locals import *


from constants import *
from utils import *
from core import *
from mycreatepathnetwork import *
from mynavigatorhelpers import *


###############################
# AStarNavigator
###
# Creates a path node network and implements the A* algorithm to create a path to the given destination.

class AStarNavigator(NavMeshNavigator):

    def __init__(self):
        NavMeshNavigator.__init__(self)

    # Create the path node network.
    # self: the navigator object
    # world: the world object

    def createPathNetwork(self, world):
        self.pathnodes, self.pathnetwork, self.navmesh = myCreatePathNetwork(
            world, self.agent)
        return None

    # Finds the shortest path from the source to the destination using A*.
    # self: the navigator object
    # source: the place the agent is starting from (i.e., its current location)
    # dest: the place the agent is told to go to
    def computePath(self, source, dest):
        self.setPath(None)
        # Make sure the next and dist matrices exist
        if self.agent != None and self.world != None:
            self.source = source
            self.destination = dest
            # Step 1: If the agent has a clear path from the source to dest, then go straight there.
            # Determine if there are no obstacles between source and destination (hint: cast rays against world.getLines(), check for clearance).
            # Tell the agent to move to dest
            # Step 2: If there is an obstacle, create the path that will move around the obstacles.
            # Find the path nodes closest to source and destination.
            # Create the path by traversing the self.next matrix until the path node closest to the destination is reached
            # Store the path by calling self.setPath()
            # Tell the agent to move to the first node in the path (and pop the first node off the path)
            if clearShot(source, dest, self.world.getLinesWithoutBorders(), self.world.getPoints(), self.agent):
                self.agent.moveToTarget(dest)
            else:
                start = findClosestUnobstructed(
                    source, self.pathnodes, self.world.getLinesWithoutBorders())
                end = findClosestUnobstructed(
                    dest, self.pathnodes, self.world.getLinesWithoutBorders())
                if start != None and end != None:
                    # print len(self.pathnetwork)
                    newnetwork = unobstructedNetwork(
                        self.pathnetwork, self.world.getGates())
                    # print len(newnetwork)
                    closedlist = []
                    path, closedlist = astar(start, end, newnetwork)
                    if path is not None and len(path) > 0:
                        path = shortcutPath(
                            source, dest, path, self.world, self.agent)
                        self.setPath(path)
                        if self.path is not None and len(self.path) > 0:
                            first = self.path.pop(0)
                            self.agent.moveToTarget(first)
        return None

    # Called when the agent gets to a node in the path.
    # self: the navigator object
    def checkpoint(self):
        myCheckpoint(self)
        return None

    # This function gets called by the agent to figure out if some shortcuts can be taken when traversing the path.
    # This function should update the path and return True if the path was updated.
    def smooth(self):
        return mySmooth(self)

    def update(self, delta):
        myUpdate(self, delta)


def unobstructedNetwork(network, worldLines):
    newnetwork = []
    for l in network:
        hit = rayTraceWorld(l[0], l[1], worldLines)
        if hit == None:
            newnetwork.append(l)
    return newnetwork


class customNode:
    def __init__(self, state, parent, costSoFar=0, heuristic=0):

        self.costSoFar = costSoFar
        self.heuristic = heuristic
        self.totalPathCost = self.costSoFar + self.heuristic
        self.state = state
        self.parent = parent

    def __str__(self):
        return "(State:" + str(self.state) + ", " + "Parent:" + str(self.parent) + ", " + "PathCost:" + str(self.costSoFar) + ")"
        # return str(self.state)


class PriorityQueue(object):
    def __init__(self):
        self.queue = []

    def getQueue(self):
        stringArray = []
        for i in range(len(self.queue)):
            temp = self.queue[i]
            node = temp[1]
            cost = node.costSoFar
            totalCost = node.totalPathCost
            heuristic = node.heuristic
            name = node.state
            stringArray.append(name)

        return stringArray

    def pop(self):
        return heapq.heappop(self.queue)

    def replaceByIndex(self, index, node):
        self.queue[index] = node
        heapq.heapify(self.queue)

    def __iter__(self):
        return iter(sorted(self.queue))

    def __str__(self):
        """Priority Queue to string."""
        stringArray = []
        for i in range(len(self.queue)):
            temp = self.queue[i]
            node = temp[1]
            cost = node.costSoFar
            totalCost = node.totalPathCost
            heuristic = node.heuristic
            name = node.state

            stringArray.append((totalCost, name))

        listToStr = ''.join(map(str, stringArray))
        return 'PQ: ' + listToStr

    def append(self, node):
        # automatically sorts heap according to heap invariant
        heapq.heappush(self.queue, node)
        return

    def __contains__(self, key):
        return key in [n for _, n in self.queue]

    def __eq__(self, other):
        return self == other

    def size(self):
        return len(self.queue)

    def clear(self):
        self.queue = []

    def top(self):
        return self.queue[0]

    def remove(self, index):
        self.queue.pop(index)
        heapq.heapify(self.queue)

    def exists(self, nodeValue):
        # checking to see if a node contains a node by its value not by its key
        # exists returns False if no match and (index, totalpathcost, node) if match exists

        for i, x in enumerate(self.queue):

            if nodeValue == x[1].state:
                # print "match"

                return (i, x[0], x[1])

        return False

        '''
        The whole set of code above can also be rewritten in one line using list comprehension as...
            return nodeValue in (i[1] for i in self.queue)
        '''


class graph:
    def __init__(self, network):
        self.network = network
        self.connections = {}
        self.allNodes = []
        nodes = set()

        for edge in self.network:
            nodes.add(edge[0])
            nodes.add(edge[1])

        nodes = list(nodes)
        self.allNodes = nodes

        for node in nodes:
            connectingNodes = set()
            for edge in network:
                if (edge[0] == node):
                    connectingNodes.add(edge[1])
                elif(edge[1] == node):
                    connectingNodes.add(edge[0])
            connectingNodes = list(connectingNodes)
            connectingNodes.sort()
            self.connections[node] = connectingNodes

    def getConnectingNodes(self, fromNode):

        return self.connections[fromNode]


def euclidean_dist_heuristic(curr, goal):

    p1 = curr
    p2 = goal

    p1x = p1[0]
    p1y = p1[1]

    p2x = p2[0]
    p2y = p2[1]

    distance = math.sqrt(((p1y - p2y)**2) + ((p1x - p2x)**2))

    return distance


def findPath(node):
    array = []
    while True:
        if node.parent is None:
            array.append(node.state)
            break
        array.append(node.state)
        node = node.parent

    array.reverse()
    return array


def astar(init, goal, network):
    path = []
    open = []
    closed = []

    ### YOUR CODE GOES BELOW HERE ###
    heuristic = euclidean_dist_heuristic
    start = init
    navMap = graph(network)

    heuristicPathCost = heuristic(start, goal)
    rootNode = customNode(start, None, 0, heuristicPathCost)

    # print("STARTING POINT: ", start, goal, heuristic(start, goal))

    if rootNode.state == goal:
        return path, closed

    else:
        frontier = PriorityQueue()
        frontier.append((rootNode.totalPathCost, rootNode))
        explored = PriorityQueue()

        while(frontier.size > 0):
            # print("FRONTIER: ", frontier.__str__())
            currNode = frontier.pop()
            currNodeTotalPathCostKey = currNode[0]
            currNodeInstance = currNode[1]

            # print("CURRENT NODE: ", currNodeInstance.state)
            if currNodeInstance.state == goal:
                path = findPath(currNodeInstance)
                # print("GOAL FOUND!: ", currNodeInstance.state, goal, path)
                closed = explored.getQueue()
                break

            connectingNodes = navMap.getConnectingNodes(currNodeInstance.state)

            for connectNode in connectingNodes:
                endNode = connectNode
                endNodeCost = currNodeInstance.costSoFar + euclidean_dist_heuristic(
                    currNodeInstance.state, endNode)
                # print("CONNECTING NODE:", endNode, endNodeCost)
                endNodeHeuristic = heuristic(endNode, goal)

                if(explored.exists(endNode)):
                    exploredNodeRecord = explored.exists(endNode)
                    exploredNode = exploredNodeRecord[2]
                    # print("Exists in Closed",
                    #       exploredNode.costSoFar)

                    if (endNodeCost < exploredNode.costSoFar):
                        betterNode = customNode(
                            endNode, currNodeInstance, endNodeCost, endNodeHeuristic)
                        explored.remove(exploredNodeRecord[0])
                        frontier.append((betterNode.totalPathCost, betterNode))

                elif(frontier.exists(endNode)):

                    openNodeRecord = frontier.exists(endNode)
                    openNode = openNodeRecord[2]
                    # print("Exists in Open", openNode.costSoFar)
                    if (endNodeCost < openNode.costSoFar):
                        newOpenNode = customNode(
                            endNode, currNodeInstance, endNodeCost, endNodeHeuristic)

                        # print(openNodeRecord)
                        # print(openNodeRecord[0])
                        frontier.replaceByIndex(
                            openNodeRecord[0], (newOpenNode.totalPathCost, newOpenNode))

                else:
                    # print("NEITHER IN OPEN OR CLOSED")
                    # the connecting node is neither in open or closed list
                    child = customNode(
                        endNode, currNodeInstance, endNodeCost, endNodeHeuristic)

                    frontier.append((child.totalPathCost, child))

            explored.append(currNode)
        # print(path, closed.__str__())
    ### YOUR CODE GOES ABOVE HERE ###
    return path, closed


def myUpdate(nav, delta):
    ### YOUR CODE GOES BELOW HERE ###
    # print(delta)
    # nav.agent.update(delta)
    nav.setPath(None)
    ### YOUR CODE GOES ABOVE HERE ###
    return None


def myCheckpoint(nav):
    ### YOUR CODE GOES BELOW HERE ###
    start = nav.agent.position
    end = nav.agent.moveTarget
    world = nav.world
    if clearShot(start, end, world.getLines(), world.getPoints(), nav.agent):
        nav.setPath(None)

    ### YOUR CODE GOES ABOVE HERE ###
    return None


# Returns true if the agent can get from p1 to p2 directly without running into an obstacle.
# p1: the current location of the agent
# p2: the destination of the agent
# worldLines: all the lines in the world
# agent: the Agent object
def clearShot(p1, p2, worldLines, worldPoints, agent):
    ### YOUR CODE GOES BELOW HERE ###
    maxRadius = agent.getMaxRadius()
    clear = True
    if(rayTraceWorld(p1, p2, worldLines)):
        clear = False
    else:
        for obsPoint in worldPoints:
            if(minimumDistance((p1, p2), obsPoint) < maxRadius):
                clear = False
    # print(p1, p2, clear)
    if(clear):
        return True
    ### YOUR CODE GOES ABOVE HERE ###
    return False
